export const products=[
{id:1,name:"Classic Cotton T-Shirt",category:"Fashion",price:799,rating:4.6,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=80"},
{id:2,name:"Premium Casual Shirt",category:"Fashion",price:1299,rating:4.7,image:"https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=700&q=80"},
{id:3,name:"Urban Running Sneakers",category:"Footwear",price:2199,rating:4.8,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80"},
{id:4,name:"Classic Lifestyle Sneakers",category:"Footwear",price:2499,rating:4.5,image:"https://images.unsplash.com/photo-1543508282-6319a3e2621f?auto=format&fit=crop&w=700&q=80"},
{id:5,name:"Wireless Headphones",category:"Electronics",price:1799,rating:4.7,image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"},
{id:6,name:"Smart Watch Pro",category:"Electronics",price:2999,rating:4.8,image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"},
{id:7,name:"Everyday Travel Backpack",category:"Accessories",price:1599,rating:4.6,image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=80"},
{id:8,name:"Classic Sunglasses",category:"Accessories",price:999,rating:4.4,image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80"},
{id:9,name:"Latest Smartphone",category:"Electronics",price:18999,rating:4.5,image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=700&q=80"},
{id:10,name:"Slim Performance Laptop",category:"Electronics",price:54999,rating:4.8,image:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=700&q=80"},
{id:11,name:"Minimal White Tee",category:"Fashion",price:699,rating:4.3,image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=700&q=80"},
{id:12,name:"Street Style Shoes",category:"Footwear",price:1899,rating:4.6,image:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=700&q=80"}];
export const categories=["All","Fashion","Footwear","Electronics","Accessories"];